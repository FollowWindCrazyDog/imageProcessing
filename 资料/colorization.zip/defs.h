typedef double real ;

#ifndef NULL
#define NULL 0
#endif /* NULL */

#ifndef EPS
#define EPS 1e-12
#endif /* NULL */

#ifndef INF
#define INF 1e12
#endif /* INF */



